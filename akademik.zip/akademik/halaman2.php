
<body>
<right>
</span>
</right>
<center>
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
					<div class="table100-head">
	<h2>Daftar Jajan</h2>

		
		<img src="one.jpeg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>combro</h4>
		<h5>harga : 5000/bks</h5>
		<img src="dua.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>putri salju</h4>
		<h5>harga : 3000/bks</h5>
		<img src="tiga.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>cireng</h4>
		<h5>harga : 1000/pcs</h5>
		<img src="empat.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>cilok pedas</h4>
		<h5>harga : 3000/bks</h5>
		<img src="lima.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>onde-onde</h4>
		<h5>harga : 1000/pcs</h5>
		<img src="enam.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>lontong</h4>
		<h5>harga : 2000/pcs</h5>
		<img src="tujuh.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>cenil</h4>
		<h5>harga : 4000/bks</h5>
		<img src="delapan.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>lapis</h4>
		<h5>harga : 1500/pcs</h5>
		<img src="sembilan.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>getuk lindri</h4>
		<h5>harga : 1000/pcs</h5>
		<img src="sepuluh.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>kue mutiara</h4>
		<h5>harga : 2500/pcs</h5>
		<img src="sebelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>putri susu</h4>
		<h5>harga : 3000/bks</h5>
		<img src="duabelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>kue bali</h4>
		<h5>harga : 1000/pcs</h5>
		<img src="tigabelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>nagasari</h4>
		<h5>harga : 1500/pcs</h5>
		<img src="empatbelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>croket sayur</h4>
		<h5>harga : 2500/pcs</h5>
		<img src="limabelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>dadar gulung</h4>
		<h5>harga : 6000/bks</h5>
		<img src="enambelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>pisang ijo</h4>
		<h5>harga : 5000/bks</h5>
		<img src="tujuhbelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>apem</h4>
		<h5>harga : 1000/pcs</h5>
		<img src="delapanbelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>klepon</h4>
		<h5>harga : 2000/bks</h5>
		<img src="sembilanbelas.jpg" style="width: 250px; height: 140px; padding-right: 2px">
		<h4>srabi</h4>
		<h5>harga : 4000/pcs</h5>
	
	
</div>
</div>
</div>
</center>
</body>