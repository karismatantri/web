<!DOCTYPE html>
<html>
<head>
	<title>kontak</title>
</head>
<body>

<h2>contact me</h2>
	<form method="post">
			Nama
			<br>
			<input type="text" size="27" />
			<br>
			Email
			<br>
			<input type="text" size="27" />
			<br>
			Pesan
			<br>
			<textarea></textarea>
			<br>
			<input type="submit" value="send" />
	</form>
</body>
</html>