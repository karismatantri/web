<html>
<head>
	<center><title>daftar</title></center>
</head>
<body>
 
	
	
	<h2>ISI DATA PENGUNJUNG</h2>
	
	<form method="post" action="tambah_aksi.php">
		<table>
			<tr>			
				<td>Nama</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" name="alamat"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
	<a href="index2.php">KEMBALI</a>
</body>
</html>